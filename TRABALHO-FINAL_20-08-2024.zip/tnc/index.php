<?php
session_start();

// Verifica se o usuário está autenticado
if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donos do Chopp</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FullCalendar CSS -->
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.0.0/dist/fullcalendar.min.css" rel="stylesheet">
    <!-- CSS Personalizado -->
    <link rel="stylesheet" href="styles.css">

    <style>
        #calendar {
            max-width: 900px;
            margin: 0 auto;
        }
        .hero {
            background: url('img/hero-bg.jpg') no-repeat center center/cover;
            color: white;
        }
        .hero h1 {
            font-size: 3rem;
        }
        .hero p {
            font-size: 1.25rem;
        }
        .btn-primary {
            background-color: #d9534f;
            border: none;
        }
        .btn-primary:hover {
            background-color: #c9302c;
        }
        footer a {
            color: #f8f9fa;
        }
        footer a:hover {
            color: #d9534f;
        }
    </style>
</head>
<body>

    <!-- Barra de Navegação -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">Donos do Chopp</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="#home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">Sobre</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#evento">Eventos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contato</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="register.php">Registre-se</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">Sair</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>


    <!-- Seção Sobre -->
    <section id="about" class="py-5" style="background-color: lightgray;">
        <div class="container">
            <h1 class="text-center">Sobre Nós</h1> <br>
            <div class="row">
                <div class="col-md-12">
                    <h5 class="text-center">Somos uma empresa dedicada a proporcionar experiências inesquecíveis com o nosso chopp artesanal, servido sempre gelado e perfeito para cada ocasião. Com um compromisso inabalável com a qualidade e a satisfação de nossos clientes, nos destacamos por estar presentes em festas, eventos, confraternizações e muito mais. Nossa icônica Kombi, repleta de charme e tradição, é a responsável por levar o melhor do chopp artesanal a todos que apreciam uma bebida verdadeiramente excepcional.</h5> <br> <br>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <img src="img/gallery/gif.gif" class="img-fluid rounded" alt="Chopp Artesanal">
                </div>
                <div class="col-md-6">
                    <h3>O que é Chopp Artesanal?</h3>
                    <p>O chopp artesanal é uma bebida produzida com ingredientes selecionados e processos tradicionais. Cada lote é único e traz um sabor distinto que não pode ser encontrado nas grandes marcas comerciais.</p>
                    <img src="img/gallery/chopp1.png" class="img-fluid rounded" alt="Chopp Artesanal">
                </div>
            </div>
        </div>
    </section>

    <!-- Seção Eventos -->
    <section id="evento" class="py-5" style="background-color: lightgray;">
        <div class="container">
            <h2 class="text-center">Eventos</h2> <br><br>
            <div class="row d-flex justify-content-center">
                <div id="calendar"></div>
                <div class="col-md-12 mt-4 text-center">
                    <a href="calendario.php" class="btn btn-primary">Ir para Eventos</a>
                </div>
            </div>
        </div>
    </section>

     <!-- Seção de Contato -->
     <section id="contact" class="py-5" style="background-color: lightgray;">
        <div class="container">
            <h2 class="text-center">Contrate nossos serviços</h2> <br><br>
            <div class="row">
                <div class="col-md-6">
                    <a class="nav-link" href="https://www.instagram.com/donos_do_chopp?igsh=NWdhM3QzMnB4NHR1"><img src="img/gallery/logo.jpg" class="img-fluid rounded" alt="Contato"></a>
                </div>
                <div class="col-md-6">
                    <form>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="name" class="form-label">Nome</label>
                                <input type="text" class="form-control" id="name" placeholder="Seu nome">
                            </div>
                            <div class="col-md-6">
                                <label for="email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="email" placeholder="Seu email">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Mensagem</label>
                            <textarea class="form-control" id="message" rows="4" placeholder="Sua mensagem"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Enviar</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Rodapé -->
    <footer class="bg-dark text-white text-center py-3">
        <p>Kombi de Chopp para Festas e Eventos</p>
        <a class="nav-link" href="https://www.instagram.com/donos_do_chopp?igsh=NWdhM3QzMnB4NHR1"><img src="img/gallery/instagram-icon1.jpg" style="width: 30px;" class="img-fluid rounded" alt="Instagram"></a> 
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- FullCalendar JS -->
    <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.0.0/dist/fullcalendar.min.js"></script>
    <!-- JavaScript Personalizado -->
    <script src="scripts.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var calendarEl = document.getElementById('calendar');

            var calendar = new FullCalendar.Calendar(calendarEl, {
                initialView: 'dayGridMonth',
                editable: true,
                events: 'events.php',
                dateClick: function(info) {
                    // Quando um dia é clicado
                    document.getElementById('eventModalLabel').textContent = 'Adicionar Evento';
                    document.getElementById('eventForm').reset();
                    document.getElementById('eventId').value = '';
                    document.getElementById('date').value = info.dateStr;
                    new bootstrap.Modal(document.getElementById('eventModal')).show();
                },
                eventClick: function(info) {
                    // Quando um evento é clicado
                    var event = info.event;
                    document.getElementById('eventModalLabel').textContent = 'Editar Evento';
                    document.getElementById('title').value = event.title;
                    document.getElementById('description').value = event.extendedProps.description;
                    document.getElementById('date').value = event.start.toISOString().split('T')[0];
                    document.getElementById('time').value = event.start.toISOString().split('T')[1].substring(0, 5);
                    document.getElementById('eventId').value = event.id;
                    new bootstrap.Modal(document.getElementById('eventModal')).show();
                }
            });

            calendar.render();
        });
    </script>
</body>
</html>
