document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');

    var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        events: function(info, successCallback, failureCallback) {
            fetch('events.php?action=get')
                .then(response => response.json())
                .then(data => {
                    successCallback(data.events);
                })
                .catch(error => {
                    console.error('Erro ao carregar eventos:', error);
                    failureCallback(error);
                });
        },
        dateClick: function(info) {
            // Lógica para adicionar eventos aqui
            const title = prompt('Digite o título do evento:');
            if (title) {
                fetch('events.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        title: title,
                        date: info.dateStr,
                        action: 'add'
                    })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.status === 'success') {
                        calendar.refetchEvents();
                    } else {
                        alert('Erro ao adicionar evento: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Erro:', error);
                });
            }
        }
    });

    calendar.render();
});
